#ifndef __UINT2BIN__
#define __UINT2BIN__

void uint2bin(unsigned x, char bin[32]);
    
#endif

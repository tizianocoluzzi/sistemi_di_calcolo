#ifndef ES2_HEADER
#define ES2_HEADER

int crc32b(char *bytes, int n);
void get_constant(int* value, int index);

#endif
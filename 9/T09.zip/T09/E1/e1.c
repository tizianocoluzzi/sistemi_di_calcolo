#include "e1.h"

int parseCSV(const char* file, person_t** out, int minAge) {
    // scrivere qui la soluzione...
}
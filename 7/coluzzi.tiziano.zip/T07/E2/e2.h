#ifndef __BLUR5__
#define __BLUR5__

void blur5(unsigned char* in, unsigned char* out, int w, int h);

#endif


int f(int x, int y){
    int z = x + y;
    if (z > 15) return 1;
    return 0;
}
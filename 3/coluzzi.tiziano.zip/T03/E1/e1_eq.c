int min(int x, int y, int z){
    int a;
    int c = x;
    int d = y;
    if(c-d > 0) goto E;
    d = z;
    if(c-d > 0) goto A;
    a = c;
    goto R;
    A:
    a = d; 
    goto R;
    E:
    c = z;
    if(d-c > 0) goto B;
    a = d; 
    goto R;
    B:
    a = c;
    R:
    return a;
}
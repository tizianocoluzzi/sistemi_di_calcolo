int comp(const void* xv, const void* yv){
    int a;
    int* c = (int*) xv;
    int* d = (int*) yv;
    a = *c;
    a = a - *d;
    return a;
}
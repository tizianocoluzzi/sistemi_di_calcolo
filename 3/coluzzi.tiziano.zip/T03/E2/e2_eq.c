unsigned int fib(unsigned int n){
    unsigned int d = n;
    unsigned int c = 0;
    unsigned int a = 1;
    if(d != 0) goto E;
    a = c;
    goto R;
E:
    if(d != 1) goto L;
    goto R;
L:
    if(d <= 1) goto R;
    c = c + a;
    //inversione senza variabile aggiuntiva
    c = c + a;
    a = a - c;
    a = -a;
    c = c - a;
    d--;
    goto L;
R:
    return a;
}
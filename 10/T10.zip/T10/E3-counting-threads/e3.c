#include <pthread.h>
#include <stdlib.h>

#include "e3.h"

unsigned int *shared_array;

// Inserire qui la soluzione
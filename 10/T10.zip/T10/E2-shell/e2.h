#ifndef __DO_SHELL__
#define __DO_SHELL__

int do_shell(const char* prompt);

#endif


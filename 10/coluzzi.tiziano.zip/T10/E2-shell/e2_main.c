#include "e2.h"

#define PROMPT "SC> "

int main() {
    return do_shell(PROMPT);
}

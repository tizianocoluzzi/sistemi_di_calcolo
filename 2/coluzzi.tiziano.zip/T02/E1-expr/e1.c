int f() {
    int x = ((2+3)*(4-2)-(2+3))*3;
    return x + 1;
}
int f(int x) {
    return 2*x*x-7*x+1;
}
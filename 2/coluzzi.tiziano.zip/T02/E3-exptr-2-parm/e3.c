int f(int x, int y) {
    return (x+y)*(x-y);
}
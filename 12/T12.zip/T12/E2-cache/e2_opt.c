#include "e2.h"

long f_opt(const short *v, unsigned n){
    // completare la funzione
    return 0;
}

#ifndef __E1__
#define __E1__

int is_suffix(const char* s1, const char* s2);

#endif
